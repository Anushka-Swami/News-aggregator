import ColorThief from 'colorthief'

export async function extractColors(imageUrl: string): Promise<string[]> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = 'Anonymous'
    img.onload = () => {
      const colorThief = new ColorThief()
      const palette = colorThief.getPalette(img, 5)
      const colors = palette.map(color => `rgb(${color[0]}, ${color[1]}, ${color[2]})`)
      resolve(colors)
    }
    img.onerror = reject
    img.src = imageUrl
  })
}

