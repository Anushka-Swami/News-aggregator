'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ExternalLink, Search, Filter, Loader2, Sparkles, Newspaper, BarChart2, TrendingUp } from 'lucide-react'
import Image from 'next/image'
import { Navbar } from '@/components/Navbar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Define the Article interface
interface Article {
  id: number
  title: string
  description: string
  source: string
  published_at: string
  url: string
  summary: string
  category: string
  image_url: string
}

export default function Articles() {
  // State variables
  const [articles, setArticles] = useState<Article[]>([])
  const [filteredArticles, setFilteredArticles] = useState<Article[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [activeSource, setActiveSource] = useState('All')

  // Categories and sources for filtering
  const categories = ['All', 'Indian economy', 'Global economy', 'Commodities', 'Rural economy', 'Climate change']
  const sources = ['All', 'Mint', 'The Hindu Business Line', 'The Hindustan Times', 'India Today']

  // Fetch articles on component mount
  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const response = await fetch('https://news-aggregator-5tb1.onrender.com/api/articles')
        if (!response.ok) {
          throw new Error('Failed to fetch articles')
        }
        const data = await response.json()

        const articlesWithImages = data.map((article: Article, index: number) => ({
          ...article,
          image_url: `https://picsum.photos/seed/${index}/400/300`,
          category: categories[Math.floor(Math.random() * (categories.length - 1)) + 1]
        }))

        setArticles(articlesWithImages)
        setFilteredArticles(articlesWithImages)
        setIsLoading(false)
      } catch (err) {
        setError('An error occurred while fetching the articles. Please try again later.')
        setIsLoading(false)
      }
    }

    fetchArticles()
  }, [])

  // Filter articles based on search term, category, and source
  useEffect(() => {
    const filtered = articles.filter(article =>
      (activeCategory === 'All' || article.category === activeCategory) &&
      (activeSource === 'All' || article.source === activeSource) &&
      (article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.description.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    setFilteredArticles(filtered)
  }, [searchTerm, activeCategory, activeSource, articles])

  // Function to summarize content
  const summarizeContent = (text: string, maxLength: number = 300) => {
    if (text.length <= maxLength) return text
    const words = text.slice(0, maxLength).split(' ')
    words.pop()
    return words.join(' ') + '...'
  }

const ArticleCard = ({ article }: { article: Article }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })
  const [isHovered, setIsHovered] = useState(false)

  const formattedDate = article.published_at
    ? new Date(article.published_at).toLocaleDateString('en-US', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      })
    : 'Date unavailable'

  const handleCardClick = (e: React.MouseEvent) => {
    // Prevent click if clicking on footer elements
    if (!(e.target as HTMLElement).closest('.card-footer')) {
      window.open(article.url, '_blank', 'noopener,noreferrer')
    }
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.5 }}
      className="h-full card-hover-effect"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card 
        className="flex flex-col h-full border-border bg-card relative overflow-hidden group cursor-pointer"
        onClick={handleCardClick}
      >
        {/* Hover effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-primary/5 to-primary/10 opacity-0 transition-opacity duration-300"
          animate={{ opacity: isHovered ? 1 : 0 }}
        />
        
        {/* Card Header */}
        <CardHeader className="relative p-0">
          <div className="relative h-48 w-full overflow-hidden">
            <Image
              src={article.image_url}
              alt={article.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
            <motion.div
              className="absolute top-4 right-4"
              initial={{ scale: 0 }}
              animate={{ scale: isHovered ? 1 : 0 }}
              transition={{ duration: 0.3 }}
            >
              <Badge variant="secondary" className="backdrop-blur-sm">
                <Sparkles className="w-4 h-4 mr-1" />
                AI Analyzed
              </Badge>
            </motion.div>
          </div>

          <div className="p-6">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <CardTitle className="text-2xl mb-2 font-orbitron gradient-text">
                {article.title}
              </CardTitle>
              <CardDescription className="flex items-center text-sm">
                <time dateTime={article.published_at} className="font-space-grotesk">
                  {formattedDate}
                </time>
              </CardDescription>
            </motion.div>
          </div>
        </CardHeader>

        {/* Card Content */}
      <CardContent className="flex-grow px-6">
        <div className="content-fade">
      <p className="text-base text-muted-foreground font-space-grotesk leading-relaxed">
      {(() => {
        const sentences = article.description?.split('. ') || []; // Split description into sentences
        const firstFive = sentences.slice(0, 3).join('. '); // Join the first 3 sentences
        return sentences.length > 5 ? `${firstFive}...` : firstFive; // Add ellipses if more than 3 sentences
      })()}
      </p>
        </div>
     </CardContent>


        {/* Card Footer */}
        <CardFooter className="flex justify-between items-center card-footer">
          <Badge variant="secondary">{article.source}</Badge>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-blue-500 hover:text-blue-700 transition-colors duration-200 flex items-center"
            onClick={(e) => {
              e.stopPropagation()
              window.open(article.url, '_blank', 'noopener,noreferrer')
            }}
          >
            Read More <ExternalLink className="ml-1 h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  )
}

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-background">
        {/* Header Section */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-primary/10 to-background" />
          <div className="container mx-auto px-4 pt-32 pb-24">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="text-center relative z-10 space-y-8"
            >
              <h1 className="text-7xl font-bold text-foreground font-orbitron gradient-text tracking-tight">
                AI-Curated News
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-space-grotesk leading-relaxed">
                Experience news through the lens of artificial intelligence, delivering personalized insights and analysis for the modern reader.
              </p>

              {/* Feature Highlights */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto mt-12">
                {/* Feature Block 1 */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="flex flex-col items-center space-y-3"
                >
                  <div className="p-3 bg-primary/10 rounded-full">
                    <Newspaper className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg">Curated Content</h3>
                  <p className="text-sm text-muted-foreground">Stay updated with AI-curated news, sourced from trusted platforms.</p>
                </motion.div>

                {/* Feature Block 2 */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="flex flex-col items-center space-y-3"
                >
                  <div className="p-3 bg-primary/10 rounded-full">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg">Trending Topics</h3>
                  <p className="text-sm text-muted-foreground">Discover the most talked-about topics in the Indian economy and beyond.</p>
                </motion.div>

                {/* Feature Block 3 */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  className="flex flex-col items-center space-y-3"
                >
                  <div className="p-3 bg-primary/10 rounded-full">
                    <BarChart2 className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg">AI Analysis</h3>
                  <p className="text-sm text-muted-foreground">AI-driven insights and summarization for better understanding.</p>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="container mx-auto mt-16 px-4">
          <div className="relative max-w-lg mx-auto">
            <Input
              type="text"
              placeholder=""
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border-2 border-primary px-6 py-3 rounded-full w-full bg-background text-primary placeholder:text-muted-foreground"
            />
            <div className="absolute top-1/2 left-4 transform -translate-y-1/2 text-primary">
              <Search />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="container mx-auto mt-16 px-4">
          <div className="flex justify-between space-x-4">
            {/* Category Filter */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center space-x-2">
                  <Filter className="w-4 h-4" />
                  <span>{activeCategory}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {categories.map((category) => (
                  <DropdownMenuItem key={category} onClick={() => setActiveCategory(category)}>
                    {category}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Source Filter */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center space-x-2">
                  <Search className="w-4 h-4" />
                  <span>{activeSource}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {sources.map((source) => (
                  <DropdownMenuItem key={source} onClick={() => setActiveSource(source)}>
                    {source}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Articles */}
        <div className="container mx-auto mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          <AnimatePresence>
            {isLoading ? (
              <div className="col-span-full text-center">
                <Loader2 className="animate-spin w-8 h-8 text-primary mx-auto" />
              </div>
            ) : error ? (
              <div className="col-span-full text-center text-red-500">{error}</div>
            ) : (
              filteredArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))
            )}
          </AnimatePresence>
        </div>
      </main>
    </>
  )
}

