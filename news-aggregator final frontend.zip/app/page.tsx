'use client'
import { motion, useScroll, useTransform, useSpring, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { ThemeToggle } from '@/components/theme-toggle'
import Link from 'next/link'
import { ArrowRight, Brain, Globe, Zap, ChevronDown, Sparkles, BarChart3, Network, Lock, Cpu } from 'lucide-react'
import { useRef, useState, useEffect } from 'react'
import { useInView } from 'react-intersection-observer'

export default function Home() {
  const containerRef = useRef(null)
  const { scrollY } = useScroll()
  const [isLoaded, setIsLoaded] = useState(false)
  
  useEffect(() => {
    setIsLoaded(true)
  }, [])

  // Parallax effects
  const y = useSpring(
    useTransform(scrollY, [0, 1000], [0, 200]),
    { stiffness: 100, damping: 30 }
  )

  return (
    <div ref={containerRef} className="relative">
      {/* Theme Toggle */}
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle />
      </div>

      {/* Hero Section */}
      <div className="relative z-10 flex flex-col items-center min-h-screen">
        <div className="flex flex-col items-center justify-center px-4 pt-32 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="relative"
          >
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="mb-8"
            >
              <span className="px-6 py-2 text-sm tracking-wider text-muted-foreground border border-border rounded-full backdrop-blur-sm">
                <motion.span
                  animate={{ opacity: [1, 0.5, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="mr-2 text-primary"
                >
                  ●
                </motion.span>
                AI NEWS
              </span>
            </motion.div>

            <motion.h1 
              className="text-6xl md:text-8xl font-bold mb-8 text-foreground font-orbitron tracking-tight"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              NewsPulse
            </motion.h1>

            <motion.p 
              className="text-xl md:text-2xl mb-12 text-muted-foreground max-w-2xl mx-auto font-space-grotesk leading-relaxed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              Experience news through the lens of advanced artificial intelligence, 
              delivering insights with unprecedented clarity and depth.
            </motion.p>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="flex gap-4 justify-center"
            >
              <Link href="/articles">
                <Button 
                  size="lg" 
                  className="font-semibold px-8 py-6 rounded-full transition-transform duration-200 transform hover:scale-105"
                >
                  Explore Intelligence <ArrowRight className="ml-2" />
                </Button>
              </Link>
              <Link href="/about">
                <Button 
                  size="lg" 
                  variant="outline"
                  className="font-semibold px-8 py-6 rounded-full"
                >
                  Learn More
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>

        {/* Features Grid */}
         <motion.div
      className="w-full max-w-7xl mx-auto px-4 mt-32 mb-20"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.8 }}
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <FeatureCard
          icon={<Brain className="h-8 w-8 text-white-500" />}
          title="Neural Analysis"
          description="Advanced algorithms process and analyze news in real-time, providing deeper insights and connections."
        />
        <FeatureCard
          icon={<Globe className="h-8 w-8 text-white-500" />}
          title="Global Perspective"
          description="Access and understand news from every corner of the world, breaking down language and cultural barriers."
        />
        <FeatureCard
          icon={<Zap className="h-8 w-8 text-white-500" />}
          title="Instant Intelligence"
          description="Get real-time updates and smart summaries, staying ahead of global developments."
        />
       </div>
        </motion.div>

        {/* Stats Section */}
        <StatsSection />

        {/* How It Works Section */}
        <HowItWorksSection />

        {/* AI Capabilities Section */}
        <AICapabilitiesSection />

        {/* Scroll Indicator */}
        <motion.div 
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <ChevronDown className="w-6 h-6 text-muted-foreground" />
        </motion.div>
      </div>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  const [ref, inView] = useInView({
    threshold: 0.2,
    triggerOnce: true
  })

  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5 }}
      className="group"
    >
      <div className="h-full p-8 bg-card/50 backdrop-blur-sm border border-border rounded-2xl transition-transform duration-300 hover:translate-y-[-4px]">
        <motion.div 
          className="flex justify-center items-center h-16 w-16 mb-6 rounded-full bg-muted text-foreground mx-auto"
          whileHover={{ scale: 1.1, rotate: 5 }}
          transition={{ type: "spring", stiffness: 300 }}
        >
          {icon}
        </motion.div>
        <h2 className="text-xl font-bold mb-4 text-foreground font-orbitron">{title}</h2>
        <p className="text-muted-foreground font-space-grotesk leading-relaxed">{description}</p>
      </div>
    </motion.div>
  )
}

function StatsSection() {
  const [ref, inView] = useInView({
    threshold: 0.2,
    triggerOnce: true
  })

  const stats = [
    { value: "4+", label: "News Websites" },
    { value: "<50ms", label: "Processing Time" },
    { value: "100+", label: "Articles Analyzed" },
    { value: "5 hours", label: "Real-time Updates" }
  ]

  return (
    <motion.div
      ref={ref}
      className="w-full bg-card/50 backdrop-blur-sm border-y border-border my-32 py-20"
      initial={{ opacity: 0 }}
      animate={inView ? { opacity: 1 } : {}}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="text-4xl md:text-5xl font-bold text-foreground mb-2 font-orbitron">
                {stat.value}
              </div>
              <div className="text-muted-foreground font-space-grotesk">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  )
}

function HowItWorksSection() {
  const [ref, inView] = useInView({
    threshold: 0.2,
    triggerOnce: true
  })

  const steps = [
    {
      icon: <Network />,
      title: "Data Collection",
      description: "Our AI continuously scans and aggregates news from thousands of trusted sources worldwide."
    },
    {
      icon: <Cpu />,
      title: "Neural Processing",
      description: "Advanced neural networks analyze and categorize information, identifying patterns and connections."
    },
    {
      icon: <Sparkles />,
      title: "Intelligence Generation",
      description: "AI synthesizes insights and generates comprehensive, unbiased analysis of global events."
    }
  ]

  return (
    <motion.div
      ref={ref}
      className="w-full max-w-7xl mx-auto px-4 my-32"
      initial={{ opacity: 0 }}
      animate={inView ? { opacity: 1 } : {}}
      transition={{ duration: 0.8 }}
    >
      <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-16 text-center font-orbitron">
        How It Works
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        {steps.map((step, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: index * 0.2 }}
            className="relative"
          >
            <div className="flex flex-col items-center text-center">
              <motion.div
                className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-6 text-foreground"
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                {step.icon}
              </motion.div>
              <h3 className="text-xl font-bold text-foreground mb-4 font-orbitron">{step.title}</h3>
              <p className="text-muted-foreground font-space-grotesk">{step.description}</p>
            </div>
            {index < steps.length - 1 && (
              <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-border to-transparent transform -translate-x-1/2" />
            )}
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

function AICapabilitiesSection() {
  const [ref, inView] = useInView({
    threshold: 0.2,
    triggerOnce: true
  })

  const capabilities = [
    {
      icon: <BarChart3 />,
      title: "Trend Analysis",
      description: "Identify emerging patterns and predict future developments with advanced predictive modeling."
    },
    {
      icon: <Lock />,
      title: "Bias Detection",
      description: "Advanced algorithms detect and filter bias, ensuring balanced and objective news coverage."
    }
  ]

  return (
    <motion.div
      ref={ref}
      className="w-full bg-card/50 backdrop-blur-sm border-t border-border py-32"
      initial={{ opacity: 0 }}
      animate={inView ? { opacity: 1 } : {}}
      transition={{ duration: 0.8 }}
    >
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-16 text-center font-orbitron">
          AI Capabilities
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {capabilities.map((capability, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="bg-background/30 border border-border rounded-2xl p-8"
            >
              <motion.div
                className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-6 text-foreground"
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                {capability.icon}
              </motion.div>
              <h3 className="text-xl font-bold text-foreground mb-4 font-orbitron">{capability.title}</h3>
              <p className="text-muted-foreground font-space-grotesk">{capability.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  )
}

