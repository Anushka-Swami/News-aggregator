'use client'

import React, { useEffect, useState, useRef } from 'react'
import { Github, Mail, Linkedin, Newspaper, Code, Database, Terminal, Globe } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Navbar } from '@/components/Navbar'
import { motion, useScroll, useTransform } from 'framer-motion'

const FadeInSection = ({ children, direction = 'up' }) => {
  const [isVisible, setIsVisible] = useState(false)
  const domRef = useRef(null)

  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        setIsVisible(true)
      }
    })

    if (domRef.current) {
      observer.observe(domRef.current)
    }

    return () => {
      if (domRef.current) {
        observer.unobserve(domRef.current)
      }
    }
  }, [])

  const slideDirections = {
    up: 'translate-y-10',
    down: '-translate-y-10',
    left: 'translate-x-10',
    right: '-translate-x-10',
  }

  return (
    <div
      ref={domRef}
      className={`transform transition-all duration-1000 ease-out
        ${isVisible ? 'opacity-100 translate-y-0 translate-x-0' : `opacity-0 ${slideDirections[direction]}`}`}
    >
      {children}
    </div>
  )
}

const AboutPage = () => {
  const { scrollYProgress } = useScroll()
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0])
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.8])

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-300">
      <Navbar />

      {/* Hero Section */}
      <motion.div 
        className="relative overflow-hidden py-16 sm:py-24 px-4 sm:px-6 lg:px-8"
        style={{ opacity, scale }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-gray-100 to-transparent dark:from-gray-800 dark:to-transparent" />
        <FadeInSection>
    <div className="max-w-4xl mx-auto text-center relative z-10">
      {/* Icon */}
      <Newspaper className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-6 sm:mb-8 text-gray-700 dark:text-gray-300" />
      
      {/* Title */}
      <h1 className="text-3xl sm:text-3xl md:text-3xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-gray-700 to-gray-900 dark:from-gray-300 dark:to-gray-100 bg-clip-text text-transparent leading-tight sm:leading-snug">
        News Aggregator
      </h1>
      
      {/* Description */}
      <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-400 leading-relaxed max-w-2xl mx-auto">
        Explore the world's stories through innovation and cutting-edge technology, beautifully designed for modern readers.
      </p>
    </div>
  </FadeInSection>
      </motion.div>

      {/* Features Grid */}
      <div className="max-w-6xl mx-auto grid sm:grid-cols-2 gap-6 sm:gap-8 px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        {[
          {
            icon: <Globe className="w-8 h-8 text-gray-700 dark:text-gray-300" />,
            title: "Global Coverage",
            description: "Aggregating news from diverse sources worldwide, providing comprehensive coverage of global events."
          },
          {
            icon: <Terminal className="w-8 h-8 text-gray-700 dark:text-gray-300" />,
            title: "AI-Powered Analysis",
            description: "Leveraging advanced algorithms to categorize and prioritize news based on relevance and importance."
          },
          {
            icon: <Code className="w-8 h-8 text-gray-700 dark:text-gray-300" />,
            title: "Modern Architecture",
            description: "Built with the latest web technologies ensuring scalability, speed, and reliability."
          },
          {
            icon: <Database className="w-8 h-8 text-gray-700 dark:text-gray-300" />,
            title: "Real-Time Updates",
            description: "Continuous monitoring and updating of news sources to deliver the latest information."
          }
        ].map((feature, index) => (
          <FadeInSection key={index} direction={index % 2 === 0 ? 'left' : 'right'}>
            <Card className="bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition-all duration-300">
              <CardContent className="p-6 sm:p-8">
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl sm:text-2xl font-semibold mb-3 text-gray-800 dark:text-gray-200">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          </FadeInSection>
        ))}
      </div>

      {/* About Me Section */}
      <FadeInSection direction="up">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <Card className="bg-gray-50 dark:bg-gray-800">
            <CardContent className="p-6 sm:p-8">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="relative w-32 h-32 sm:w-48 sm:h-48 rounded-full overflow-hidden flex-shrink-0">
                  <div className="absolute inset-0 bg-gradient-to-br from-gray-300 to-gray-500 dark:from-gray-600 dark:to-gray-800 animate-pulse" />
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h3 className="text-2xl sm:text-3xl font-bold mb-4 bg-gradient-to-r from-gray-700 to-gray-900 dark:from-gray-300 dark:to-gray-100 bg-clip-text text-transparent">
                    Anushka
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
                    A full-stack developer passionate about creating innovative digital experiences. 
                    With expertise in modern web technologies and AI integration, I focus on building 
                    solutions that combine functionality with elegant design. Beyond coding, I'm an 
                    advocate for open-source development and continuously explore emerging technologies.
                  </p>
                  <div className="flex justify-center md:justify-start gap-6">
                    {[
                      { icon: <Github className="w-6 h-6" />, url: 'https://github.com/Anushka-Swami' },
                      { icon: <Linkedin className="w-6 h-6" />, url: "https://www.linkedin.com/in/anushka-swami-03a9b1237" },
                      { icon: <Mail className="w-6 h-6" />, url: "justtobeprecise@gmail.com" }
                    ].map((social, index) => (
                      <a
                        key={index}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transform hover:scale-110 transition-all duration-300"
                      >
                        {social.icon}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </FadeInSection>

      {/* Tech Stack */}
      <FadeInSection direction="up">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 sm:pb-20">
          <Card className="bg-gray-50 dark:bg-gray-800">
            <CardContent className="p-6 sm:p-8">
              <h2 className="text-xl sm:text-2xl font-bold mb-6 sm:mb-8 text-center bg-gradient-to-r from-gray-700 to-gray-900 dark:from-gray-300 dark:to-gray-100 bg-clip-text text-transparent">
                Built With Modern Tech Stack
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 sm:gap-8">
                {[
                  { title: "Frontend", tech: "React + TypeScript" },
                  { title: "Backend", tech: "Python + Flask" },
                  { title: "Database", tech: "PostgreSQL" },
                  { title: "Deployment", tech: "Render + Vercel" }
                ].map((stack, index) => (
                  <div key={index} className="text-center transform hover:scale-105 transition-transform duration-300">
                    <div className="font-semibold text-gray-800 dark:text-gray-200 mb-2">{stack.title}</div>
                    <p className="text-gray-600 dark:text-gray-400">{stack.tech}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </FadeInSection>
    </div>
  )
}

export default AboutPage

