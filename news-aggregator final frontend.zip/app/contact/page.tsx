'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, Phone, MessageSquare, ArrowRight, Loader2, MapPin } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Navbar } from '@/components/Navbar'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

const FadeIn = ({ children }) => {
  const [isVisible] = useState(true)
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
      transition={{ duration: 0.5 }}
    >
      {children}
    </motion.div>
  )
}

const InputField = ({ icon: Icon, type, placeholder, value, onChange }) => (
  <div className="relative">
    <Icon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 w-5 h-5" />
    <Input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      className="pl-10 bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-gray-100 focus:ring-gray-500 focus:border-gray-500 block w-full rounded-md"
    />
  </div>
)

const ContactPage = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setSubmitted(true)
  }

  const handleChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormState(prev => ({ ...prev, [field]: e.target.value }))
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 transition-colors duration-300">
      <Navbar />
      <div className="py-12 sm:py-16 md:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <FadeIn>
            <div className="text-center mb-12 sm:mb-16">
              <h1 className="text-4xl sm:text-5xl font-bold mb-4 text-gray-900 dark:text-gray-100">
                Get in Touch
              </h1>
              <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                Have questions about our news aggregator? We'd love to hear from you.
                Send us a message and we'll respond as soon as possible.
              </p>
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
              <Card className="bg-white dark:bg-gray-800 shadow-xl flex-1">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-center text-gray-900 dark:text-gray-100">Contact Us</CardTitle>
                </CardHeader>
                <CardContent className="p-6 sm:p-8">
                  {submitted ? (
                    <Alert className="bg-green-100 dark:bg-green-900 border-green-400 dark:border-green-700">
                      <AlertDescription className="text-green-800 dark:text-green-200">
                        Thanks for reaching out! We'll get back to you soon.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                      <InputField
                        icon={Mail}
                        type="text"
                        placeholder="Your Name"
                        value={formState.name}
                        onChange={handleChange('name')}
                      />
                      <InputField
                        icon={Mail}
                        type="email"
                        placeholder="Email Address"
                        value={formState.email}
                        onChange={handleChange('email')}
                      />
                      <InputField
                        icon={Phone}
                        type="tel"
                        placeholder="Phone Number (Optional)"
                        value={formState.phone}
                        onChange={handleChange('phone')}
                      />
                      <div className="relative">
                        <MessageSquare className="absolute left-3 top-4 text-gray-400 dark:text-gray-500 w-5 h-5" />
                        <Textarea
                          placeholder="Your Message"
                          value={formState.message}
                          onChange={handleChange('message')}
                          rows={4}
                          className="pl-10 bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-900 dark:text-gray-100 focus:ring-gray-500 focus:border-gray-500 block w-full rounded-md"
                        />
                      </div>
                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-gray-900 dark:bg-gray-100 hover:bg-gray-700 dark:hover:bg-gray-300 text-white dark:text-gray-900 font-bold py-2 px-4 sm:py-3 sm:px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105 flex items-center justify-center"
                      >
                        {isSubmitting ? (
                          <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                          <>
                            <span>Send Message</span>
                            <ArrowRight className="w-5 h-5 ml-2" />
                          </>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>

              <div className="flex-1">
                <Card className="bg-white dark:bg-gray-800 shadow-xl h-full">
                  <CardContent className="p-6 sm:p-8">
                    <div className="relative h-48 sm:h-64 mb-6">
                      {/*Image*/}
                      <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col items-center justify-center text-white p-4">
                        <h3 className="text-xl sm:text-2xl font-bold mb-2">We're Here to Help</h3>
                        <p className="text-center text-sm sm:text-base">
                          Our team is ready to assist you with any questions or concerns you may have.
                        </p>
                      </div>
                    </div>
                    <h2 className="text-xl sm:text-2xl font-bold mb-4 text-gray-900 dark:text-gray-100">Our Office</h2>
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <MapPin className="w-5 h-5 mr-2 text-gray-500" />
                        <p className="text-gray-600 dark:text-gray-400">123 News Street, City, Country</p>
                      </div>
                      <div className="flex items-center">
                        <Phone className="w-5 h-5 mr-2 text-gray-500" />
                        <p className="text-gray-600 dark:text-gray-400">+1 (123) 456-7890</p>
                      </div>
                      <div className="flex items-center">
                        <Mail className="w-5 h-5 mr-2 text-gray-500" />
                        <p className="text-gray-600 dark:text-gray-400">contact@neuranews.com</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </FadeIn>
        </div>
      </div>
    </div>
  )
}

export default ContactPage

